       #DBMS
database management system
     